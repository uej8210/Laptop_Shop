import { config } from 'dotenv';
import Users from '../model/user.model.js';
import jwt from 'jsonwebtoken';

export const getById = async (req, res, next) => {
	try {
		const user = await Users.findById(req.params.id);
		if (!user) {
			return res.status(404).json({ message: 'User not found' });
		}
		res.status(200).json({ message: 'Get By Id successfully', data: user });
	} catch (error) {
		console.log(error.message);
		res.status(500).json({ message: error.message });
	}
};

export const registerUser = async (req, res) => {
	try {
		const currentUser = await Users.findOne({
			email: req.body.email,
		});
		if (currentUser) {
			return res.status(403).json({ message: 'User already exists' });
		}
		const newUser = new Users({
			fullname: req.body.fullname,
			password: req.body.password,
			email: req.body.email,
		});
		await newUser.save();
		res
			.status(201)
			.json({ message: 'User created successfully', data: newUser });
	} catch (error) {
		console.log(error.message);
	}
};

export const loginUser = async (req, res) => {
	try {
		const { email, password } = req.body;
		const currentUser = await Users.findOne({
			email: email,
		});
		if (!currentUser) {
			return res.status(403).json({ message: 'User is not authorized' });
		}
		if (currentUser.password !== password) {
			res.status(403).json({ message: 'Email or password wrong' });
		}
		console.log(currentUser);
		const token = jwt.sign({ currentUser }, process.env.JWT_KEY, {
			expiresIn: '3d',
		});

		res.status(200).json({ token: token });
	} catch (error) {
		console.log(error.message);
		res.status(500).json({ message: error.message });
	}
};

export const updateUser = async (req, res) => {
	try {
		await Users.findByIdAndUpdate(
			req.params.id,
			{
				$set: { ...req.body },
			},
			{ new: true }
		);
		res.status(200).json({ message: 'User updated successfully' });
	} catch (error) {
		console.log(error.message);
	}
};

export const deleteUser = async (req, res) => {
	try {
		await Users.deleteOne({
			_id: req.params.id,
		});
		res.status(200).json({ message: 'User deleted successfully' });
	} catch (error) {
		console.log(error);
	}
};
