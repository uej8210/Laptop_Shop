import Notebocks from '../model/notebook.model.js';

export const getById = async (req, res) => {
	try {
		const notebook = await Notebocks.findById(req.params.id)
		.populate(
			'UserId',
			'fullName email password'
		);
		if (!notebook) {
			return res.status(404).json({ message: 'notebook not found' });
		}
		res.status(200).json({ message: 'Get By Id successfully', data: notebook });
	} catch (error) {
		console.log(error.message);
		res.status(500).json({ message: error.message });
	}
};

export const addNotebook = async (req, res) => {
	try {
		console.log(req.user);

		const newNotebook = new Notebocks({
			title: req.body.title,
			img: '/' + req.file.filename,
			price: req.body.price,
			descr: req.body.descr,
			userId: req.user._id,
		});
		await newNotebook.save();
		res
			.status(201)
			.json({ message: 'notebook created successfully', data: newNotebook });
	} catch (error) {
		console.log(error.message);
	}
};

export const updatedNotebook = async (req, res) => {
	try {
		await Notebocks.findByIdAndUpdate(
			req.params.id,
			{
				$set: { ...req.body },
			},
			{ new: true }
		);
		res.status(200).json({ message: 'Updated notebook successfully' });
	} catch (error) {
		console.log(error);
	}
};

export const deleteNotebook = async (req, res) => {
	try {
		await Notebocks.deleteOne({
			_id: req.params.id,
		});
		res.status(200).json({ message: 'Notebook deleted successfully' });
	} catch (error) {
		console.log(error);
	}
};
