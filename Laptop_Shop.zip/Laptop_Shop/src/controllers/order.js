import Order from '../model/order';
import Notebocks from '../model/notebook.model.js';

export const addOrder = async (req, res) => {
	try {
		const currentNoutbook = await Notebocks.findById(req.params.noutbukId);

		const currentOrder = await Order.findOne({
			userId: req.user._id,
			active: false,
		});
		if (currentOrder) {
			const filter = currentOrder.noutbooks.find(
				(obj = obj.noutbook._id.toString() === req.params.noutbookId.toString())
			);
			if (filter) {
				const newArray = currentOrder.noutbooks.map(ob => {
					if (ob.noutbook._id.toString === req.params.noutbookId.toString()) {
						ob.count++;
					}
					return ob;
				});
				await Order.findByIdAndUpdate(
					currentOrder._id,
					{
						$set: { noutbooks: newArray },
					},
					{ new: true }
				);
				return res
					.status(201)
					.json({ message: 'created successfully', data: newArray });
			}
			if (!filter) {
				await Order.findByIdAndUpdate(
					currentOrder._id,
					{
						$push: { noutbooks: { noutbook: currentNoutbook, count: 1 } },
					},
					{ new: true }
				);
				return res.status(201).json({
					message: 'Order added successfully',
					data: newArray,
				});
			}
		}

		const newOrder = new Order({
			noutbooks: [{ noteboock: currentNoutbook }],
			userId: req.user._id,
		});
		await newOrder.save();
		res
			.status(201)
			.json({ message: 'Order added successfully', data: newOrder });
	} catch (error) {
		console.log(error.message);
		res.status(500).json({ message: error.message });
	}
};

export const deleteNotebookByOrder = async (req, res) => {
	const order = await Order.findOne({ userId: req.user._id });
	const filter = order.noutbooks.find(
		(obj = obj.noutbook._id.toString() === req.params.noutbookId.toString())
	);
	if (filter.count > 0) {
		{
			console.log('-1');
			const newArray = order.noutbooks.map(obj => {
				if (obj.noutbook._id.toString() === req.params.noutbookId.toString()) {
					obj.count--;
				}
				return obj;
			});
			await Order.findByIdAndUpdate(
				{ _id: order._id },
				{
					$set: {
						noutbooks: newArray,
					},
				},
				{ new: true }
			);
			if (filter.count === 0) {
				const newArray = order.noutbooks.filter();
				obj => obj.noutbook._id.toString() !== req.params.noutbookId.toString();
			}
			if (!newArray.length) {
				await Order.findByIdAndDelete(order._id);
				return res
					.status(200)
					.json({ message: 'Order Deleted succesfully', data: true });
			}
			await Order.findByIdAndUpdate(
				{ _id: request.params.orderId },
				{
					$set: {
						noutbooks: newArray,
					},
				},
				{ new: true }
			);
		}
		res.status(200).json({ message: 'Delete successfully' });
	}
};

export const sendOrder = async (req, res) => {
	try {
		await Order.findByIdAndUpdate(
			{ _id: req.params.orderId },
			{
				$set: {
					active: true
				},
			},
			{ new: true }
		);
		return res
			.status(200)
			.json({ message: 'Order Added succesfully', data: true });
	} catch (error) {
		console.log(error.message);
		res.status(500).json({ message: error.message });
	}
}