import { Router } from 'express';
const router = Router();

import { verifyToken } from '../middleware/verify.js';
import upload from '../middleware/fileUpload.js';
import { addNotebook, deleteNotebook, getById, updatedNotebook } from '../controllers/notebook.js';

router.get('/byid/:id', getById)
router.post('/add', verifyToken, upload.single('img'), addNotebook);
router.put('/update/:id', updatedNotebook);
router.delete('/delete/:id', deleteNotebook);

export default router;