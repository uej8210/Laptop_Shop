import { Router } from "express";
const router = Router();

import { addOrder, deleteNotebookByOrder } from "../controllers/order";
import { verifyToken } from "../middleware/verify";

router.get('/byid/:id', );
router.post('/add/:notebookId', verifyToken ,addOrder);
router.put('/update/:id', deleteNotebookByOrder);
router.delete('/delete/:id', );

export default router