import { Router } from 'express';
const router = Router();

import { deleteUser, getById, loginUser, registerUser, updateUser } from '../controllers/auth.js';

router.get('/byid/:id', getById);
router.post('/regester', registerUser);
router.post('/login', loginUser);
router.put('/update/:id', updateUser);
router.delete('/delete/:id', deleteUser);

export default router;
