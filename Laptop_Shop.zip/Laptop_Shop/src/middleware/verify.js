import jwt from 'jsonwebtoken';
export const verifyToken = (req, res, next) => {
	try {
		const token = req.headers.authorization;
		jwt.verify(token, process.env.JWT_KEY, (err, data) => {
			if (err) {
				return res.status(403).json({ message: 'Invalid token', error: err });
			}
			req.user = data.currentUser;
			next();
		});
	} catch (error) {
		console.log(error.message);
	}
};
