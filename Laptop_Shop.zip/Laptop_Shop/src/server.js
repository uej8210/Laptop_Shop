import express from 'express';
import { config } from 'dotenv';
import 'colors';
import { connectDb } from './config/db.js';
import path from 'path'
config();
connectDb();

const app = express();


app.use(express.json());
app.use(express.urlencoded({ extended: false }));

app.use(express.static(path.join(process.cwd(), 'upload')));


import authRouter from './routers/auth.js';
import notebookRouter from './routers/notebook.js';

app.use('/api/notebook/auth', authRouter); 
app.use('/api/notebook/', notebookRouter);


const PORT = process.env.PORT || 3000;
app.listen(PORT, console.log(`Server listening on ${PORT}`.blue));
