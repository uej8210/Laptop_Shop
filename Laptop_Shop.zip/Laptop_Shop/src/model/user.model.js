import { Schema, model } from 'mongoose';

const userSchema = new Schema(
	{
		fullname: { type: 'string', required: true },
		// img: { type: 'string', required: true },
		password: { type: 'string', required: true },
		email: {
			type: 'string',
			required: true,
			match: [
				/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/,
				'Please fill a valid email address',
			],
			lowercase: true,
		},
		cart: {
			items: [
				{
					count: { type: 'number', required: true },
					noteboock: {
						type: Schema.Types.ObjectId,
						ref: 'Noteboocks',
						required: true,
					},
				},
			],
		},
	},
	{ timestamps: true }
);

export default model('Users', userSchema);
