import { Schema, model } from 'mongoose';

const noteboockSchema = new Schema(
	{
		title: { type: 'string', required: true },
		img: { type: 'string', required: true },
		price: { type: 'number', required: true },
		descr: {
			type: 'string',
			required: true,
		},
		userId: {
			type: Schema.Types.ObjectId,
			ref: 'Users',
			required: true,
		},
	},
	{ timestamps: true }
);

export default model('Notebocks', noteboockSchema);
